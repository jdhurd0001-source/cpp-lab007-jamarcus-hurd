# Lab 7 — Recursive and Iterative Algorithm Analysis

Each recursive algorithm has a **base case** that terminates recursion and a **recursive case** that reduces the problem. The recursive implementations contain no loops. Their iterative counterparts use loops instead of function calls.

| Algorithm | Recursive time | Recursive extra space | Iterative time | Iterative extra space |
|---|---|---|---|---|
| Factorial | O(n) | O(n) | O(n) | O(1) |
| Fibonacci (naive) | O(2^n) | O(n) | O(n) | O(1) |
| Binary search (sorted vector) | O(log n) | O(log n) | O(log n) | O(1) |
| Array sum | O(n) | O(n) | O(n) | O(1) |
| In-place array reversal | O(n) | O(n) | O(n) | O(1) |

## How the algorithms work

1. **Factorial:** Base case: n is 0 or 1, returning 1. Recursive case: multiply n by factorial(n - 1). The recursive depth is O(n), and there are O(n) calls. Negative inputs and values above 12 throw `std::logic_error` because 13! exceeds a signed 32-bit `int`.
2. **Fibonacci:** Base cases: F(0)=0, F(1)=1. Recursive case: F(n-1)+F(n-2). The naive recursive implementation repeats subproblems and makes exponentially many calls, while iteration maintains only the last two values. Maximum call depth is O(n). Inputs outside 0..46 are rejected to avoid signed 32-bit overflow. Recursive Fibonacci is useful for illustrating recursion but not efficient for large n.
3. **Binary search:** Requires a sorted vector in ascending order. Base case: left > right returns -1. Recursive case: compare the middle element, then recurse into one half. At most O(log n) levels/calls are needed. The iterative version uses the same narrowing strategy with constant auxiliary space. Empty and missing cases return -1.
4. **Array sum:** Base case: index equals the vector length, returning 0. Recursive case: current value plus the sum starting at the next index. There are n+1 calls and O(n) maximum depth. Iteration uses a running total and O(1) extra space.
5. **Reverse array:** Base case: the left and right positions meet or cross (or the array is empty). Recursive case: swap the outer pair, then recurse inward. This uses approximately n/2 calls, O(n) stack space, and swaps in the original vector. Iteration performs the same swaps with O(1) extra space.

## Comparison and trade-offs

Recursion can express divide-and-conquer problems such as binary search clearly, and it makes the shrinking subproblem explicit. Iteration avoids function-call overhead and often uses less memory. Deep recursion may overflow the call stack on large arrays or inputs, even when its time complexity is linear. Naive recursive Fibonacci is especially inefficient because its recursion tree repeats work; an iterative solution is strongly preferable for production use. Both binary-search variants assume sorted input; neither sorts or verifies the entire vector because doing so would change the algorithm's complexity. All arithmetic uses `int` as required by the starter signatures; callers should avoid sums that overflow `int`.

## Testing

Run `make test` from the repository root. The supplied Catch tests cover standard values, invalid inputs, missing search targets, empty and single-element arrays, negative values, and agreement between recursive and iterative results.
