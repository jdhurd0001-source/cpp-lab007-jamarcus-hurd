#include "project/recursive_algorithms.h"

#include <stdexcept>
#include <utility>
#include <vector>

namespace {
void validateFactorial(int n) {
    if (n < 0 || n > 12) throw std::logic_error("factorial requires 0 <= n <= 12 for int");
}
void validateFibonacci(int n) {
    if (n < 0 || n > 46) throw std::logic_error("fibonacci requires 0 <= n <= 46 for int");
}
// Base case: the search interval is empty, so the target is absent.
// Recursive case: inspect the midpoint and search only the relevant half.
int searchRange(const std::vector<int>& values, int target, int left, int right) {
    if (left > right) return -1;
    const int middle = left + (right - left) / 2;
    if (values[middle] == target) return middle;
    if (target < values[middle]) return searchRange(values, target, left, middle - 1);
    return searchRange(values, target, middle + 1, right);
}
// Base case: no elements remain to add.
// Recursive case: add the current element to the sum of the remaining elements.
int sumFrom(const std::vector<int>& values, std::size_t index) {
    if (index == values.size()) return 0;
    return values[index] + sumFrom(values, index + 1);
}
// Base case: the two indices meet or cross.
// Recursive case: swap the outer elements and process the inner interval.
void reverseRange(std::vector<int>& values, std::size_t left, std::size_t right) {
    if (left >= right) return;
    std::swap(values[left], values[right]);
    reverseRange(values, left + 1, right - 1);
}
}

int factorial(int n) {
    validateFactorial(n);
    // Base case: 0! and 1! both equal 1.
    if (n <= 1) return 1;
    // Recursive case: n! = n * (n - 1)!.
    return n * factorial(n - 1);
}

int factorialIterative(int n) {
    validateFactorial(n);
    int result = 1;
    for (int i = 2; i <= n; ++i) result *= i;
    return result;
}

int fibonacci(int n) {
    validateFibonacci(n);
    // Base cases: F(0) = 0 and F(1) = 1.
    if (n <= 1) return n;
    // Recursive case: add the two preceding Fibonacci numbers.
    return fibonacci(n - 1) + fibonacci(n - 2);
}

int fibonacciIterative(int n) {
    validateFibonacci(n);
    if (n <= 1) return n;
    int previous = 0, current = 1;
    for (int i = 2; i <= n; ++i) {
        const int next = previous + current;
        previous = current;
        current = next;
    }
    return current;
}

int binarySearch(const std::vector<int>& array, int target) {
    return searchRange(array, target, 0, static_cast<int>(array.size()) - 1);
}

int binarySearchIterative(const std::vector<int>& array, int target) {
    int left = 0, right = static_cast<int>(array.size()) - 1;
    while (left <= right) {
        const int middle = left + (right - left) / 2;
        if (array[middle] == target) return middle;
        if (target < array[middle]) right = middle - 1;
        else left = middle + 1;
    }
    return -1;
}

int arraySum(const std::vector<int>& array) {
    return sumFrom(array, 0);
}

int arraySumIterative(const std::vector<int>& array) {
    int total = 0;
    for (int value : array) total += value;
    return total;
}

void reverseArray(std::vector<int>& array) {
    if (array.empty()) return; // Base case for empty input; prevents index underflow.
    reverseRange(array, 0, array.size() - 1);
}

void reverseArrayIterative(std::vector<int>& array) {
    if (array.empty()) return;
    std::size_t left = 0, right = array.size() - 1;
    while (left < right) {
        std::swap(array[left], array[right]);
        ++left;
        --right;
    }
}
